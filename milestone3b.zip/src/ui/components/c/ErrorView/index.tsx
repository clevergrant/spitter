import React, { FC } from 'react'

const ErrorView: FC = () => {
	return (
		<div>
			The page you are looking for does not exist
		</div>
	)
}

export default ErrorView
