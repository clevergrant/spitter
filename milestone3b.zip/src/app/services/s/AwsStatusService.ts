import { StatusService } from 'app/interfaces'

import { Status } from 'app/models'

import { apiGatewayProxy } from 'app/proxy'

export class AwsStatusService implements StatusService {

	getStory = (alias: string, lastId: string, numResults: number) => new Promise<Status[]>((resolve, reject) => {
		apiGatewayProxy.getStory(alias, lastId, numResults)
			.then(resolve)
			.catch(reject)
	})

	getFeed = (alias: string, lastId: string, numResults: number) => new Promise<Status[]>((resolve, reject) => {
		apiGatewayProxy.getFeed(alias, lastId, numResults)
			.then(resolve)
			.catch(reject)
	})

	getHashtags = (hashtag: string, lastId: string, numResults: number) => new Promise<Status[]>((resolve, reject) => {
		apiGatewayProxy.getHashtags(hashtag, lastId, numResults)
			.then(resolve)
			.catch(reject)
	})

	getStatus = (id: string) => new Promise<Status>((resolve, reject) => {
		apiGatewayProxy.getStatus(id)
			.then(resolve)
			.catch(reject)
	})

	addStatus = (status: Status) => new Promise<string>((resolve, reject) => {
		apiGatewayProxy.addStatus(status)
			.then(resolve)
			.catch(reject)
	})

}

export default new AwsStatusService()
