export * from './p/ApiGatewayProxy'
