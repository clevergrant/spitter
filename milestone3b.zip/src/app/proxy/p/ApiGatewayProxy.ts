import { User, Status, Attachment } from 'app/models'

class ApiGatewayProxy {

	private ___baseUrl = `https://42l3t7qs2l.execute-api.us-west-2.amazonaws.com/v1`

	public register = (alias: string, name: string, password: string, photo: Attachment) => new Promise<User>((resolve, reject) => {
		fetch(`${this.___baseUrl}/auth`, {
			method: `POST`,
			headers: {
				'Content-Type': `application/json`,
			},
			body: JSON.stringify({
				alias,
				name,
				password,
				photo,
			}),
		}).then(r => r.json())
			.then(json => {
				const {
					user,
				} = json
				const typeduser = new User(user.name, user.alias, user.photo)
				typeduser.id = user.id
				typeduser.followers = user.followers
				typeduser.following = user.following
				resolve(typeduser)
			})
			.catch(reject)
	})

	public getUser = (alias: string) => new Promise<User>((resolve, reject) => {
		fetch(`${this.___baseUrl}/${alias}`).then(r => r.json())
			.then(json => {
				const {
					user,
				} = json
				const typeduser = new User(user.name, user.alias, user.photo)
				typeduser.id = user.id
				typeduser.followers = user.followers
				typeduser.following = user.following
				resolve(typeduser)
			})
			.catch(reject)
	})

	public editUser = (user: User) => new Promise<User>((resolve, reject) => {
		fetch(`${this.___baseUrl}/${user.alias}`, {
			method: `PATCH`,
			headers: {
				'Content-Type': `application/json`,
			},
			body: JSON.stringify(user),
		}).then(r => r.json())
			.then(json => {
				const {
					user,
				} = json
				const typeduser = new User(user.name, user.alias, user.photo)
				typeduser.id = user.id
				typeduser.followers = user.followers
				typeduser.following = user.following
				resolve(typeduser)
			})
			.catch(reject)
	})

	public deleteUser = (alias: string) => new Promise<string>((resolve, reject) => {
		fetch(`${this.___baseUrl}/${alias}`, {
			method: `DELETE`,
		}).then(r => r.json())
			.then(json => {
				resolve(json.message)
			})
			.catch(reject)
	})

	public getStory = (alias: string, lastId: string, numResults: number) => new Promise<Status[]>((resolve, reject) => {
		fetch(`${this.___baseUrl}/${alias}/story/${lastId}/${numResults}`).then(r => r.json())
			.then(json => {
				const {
					statuses,
				} = json
				const typedstatuses = statuses.map((obj: Status) => {
					const newstatus = new Status(obj.alias, obj.text, obj.attachment as Attachment)
					newstatus.id = obj.id
					newstatus.timestamp = obj.timestamp
					return newstatus
				})
				resolve(typedstatuses)
			})
			.catch(reject)
	})

	public getFeed = (alias: string, lastId: string, numResults: number) => new Promise<Status[]>((resolve, reject) => {
		fetch(`${this.___baseUrl}/${alias}/feed/${lastId === `` ? -1 : lastId}/${numResults}`)
			.then(r => r.json())
			.then(json => {
				const {
					statuses,
				} = json
				const typedstatuses = statuses.map((obj: Status) => {
					const newstatus = new Status(obj.alias, obj.text, obj.attachment as Attachment)
					newstatus.id = obj.id
					newstatus.timestamp = obj.timestamp
					return newstatus
				})
				resolve(typedstatuses)
			})
			.catch(reject)
	})

	public follow = (alias: string) => new Promise<string>((resolve, reject) => {
		fetch(`${this.___baseUrl}/friends/${alias}`, {
			method: `POST`,
		}).then(r => r.json())
			.then(json => {
				resolve(json.message)
			})
			.catch(reject)
	})

	public unfollow = (alias: string) => new Promise<string>((resolve, reject) => {
		fetch(`${this.___baseUrl}/friends/${alias}`, {
			method: `DELETE`,
		}).then(r => r.json())
			.then(json => {
				resolve(json.message)
			})
			.catch(reject)
	})

	public listFollowing = (lastId: string, numResults: number) => new Promise<User[]>((resolve, reject) => {
		fetch(`${this.___baseUrl}/friends/following/${lastId}/${numResults}`).then(r => r.json())
			.then(json => {
				const {
					users,
				} = json
				const typedusers = users.map((user: User) => {
					const newuser = new User(user.name, user.alias, user.photo as Attachment)
					newuser.id = user.id
					newuser.followers = user.followers
					newuser.following = user.following
					return newuser
				})
				resolve(typedusers)
			})
			.catch(reject)
	})

	public listFollowers = (lastId: string, numResults: number) => new Promise<User[]>((resolve, reject) => {
		fetch(`${this.___baseUrl}/friends/followers/${lastId}/${numResults}`).then(r => r.json())
			.then(json => {
				const {
					users,
				} = json
				const typedusers = users.map((user: User) => {
					const newuser = new User(user.name, user.alias, user.photo as Attachment)
					newuser.id = user.id
					newuser.followers = user.followers
					newuser.following = user.following
					return newuser
				})
				resolve(typedusers)
			})
			.catch(reject)
	})

	public addStatus = (status: Status) => new Promise<string>((resolve, reject) => {
		fetch(`${this.___baseUrl}/status`, {
			method: `POST`,
			headers: {
				'Content-Type': `application/json`,
			},
			body: JSON.stringify(status),
		}).then(r => r.json())
			.then(json => {
				resolve(json.message)
			})
			.catch(reject)
	})

	public getStatus = (id: string) => new Promise<Status>((resolve, reject) => {
		fetch(`${this.___baseUrl}/status/${id}`).then(r => r.json())
			.then(json => {
				const {
					status,
				} = json
				const typedstatus = new Status(status.alias, status.text, status.attachment as Attachment)
				typedstatus.id = status.id
				typedstatus.timestamp = status.timestamp
				resolve(typedstatus)
			})
			.catch(reject)
	})

	public getHashtags = (hashtag: string, lastId: string, numResults: number) => new Promise<Status[]>((resolve, reject) => {
		fetch(`${this.___baseUrl}/hashtag/${hashtag}/${lastId === `` ? -1 : lastId}/${numResults}`).then(r => r.json())
			.then(json => {
				const {
					statuses,
				} = json
				const typedstatuses = statuses.map((obj: Status) => {
					const newstatus = new Status(obj.alias, obj.text, obj.attachment as Attachment)
					newstatus.id = obj.id
					newstatus.timestamp = obj.timestamp
					return newstatus
				})
				resolve(typedstatuses)
			})
			.catch(reject)
	})

}

export const apiGatewayProxy = new ApiGatewayProxy()
