
class MockAuthProxy {

}

const mockAuthProxy = new MockAuthProxy()

export default mockAuthProxy